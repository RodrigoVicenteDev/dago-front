// src/pages/Painel/DashboardHome.tsx
import CardAlerta from "./components/CardAlerta";
import CardContainer from "./components/CardContainer";

import { useNavigate } from "react-router-dom";
import useDashboardData from "./Hooks/useDashboardData";

export default function DashboardHome() {
  const navigate = useNavigate();

  const {
    loading,
    erro,
    ctrcsParadosGRU,
    ctrcsParadosUND,
    ctrcsAtrasadas,
    ctrcsVaiAtrasar,
  } = useDashboardData();

  const aplicarFiltro = (ctrc: any[]) => {
    const ctrcs = ctrc.map(c => c.numero);

    localStorage.setItem("filtroDashboardCtrcs", JSON.stringify(ctrcs));

    navigate("/minha-tabela?fromDashboard=1");
  };

  if (loading)
    return (
      <div className="p-8 text-center text-slate-500">
        Carregando dashboard...
      </div>
    );

  if (erro)
    return (
      <div className="p-8 text-center text-red-500">
        {erro}
      </div>
    );

  return (
    <div className="p-6 bg-white rounded-2xl shadow-sm border border-slate-200">
      <h1 className="text-2xl font-semibold text-slate-800 mb-6">
        Painel Operacional
      </h1>

      <CardContainer>
        <CardAlerta
          titulo="Notas em atraso"
          quantidade={ctrcsAtrasadas.length}
          cor="text-red-600"
          onClick={() => aplicarFiltro(ctrcsAtrasadas)}
        />

        <CardAlerta
          titulo="Vencem amanhã"
          quantidade={ctrcsVaiAtrasar.length}
          cor="text-amber-600"
          onClick={() => aplicarFiltro(ctrcsVaiAtrasar)}
        />

        <CardAlerta
          titulo="Paradas no parceiro"
          quantidade={ctrcsParadosUND.length}
          cor="text-blue-600"
          onClick={() => aplicarFiltro(ctrcsParadosUND)}
        />

        <CardAlerta
          titulo="Paradas na Expedição (GRU)"
          quantidade={ctrcsParadosGRU.length}
          cor="text-purple-600"
          onClick={() => aplicarFiltro(ctrcsParadosGRU)}
        />
      </CardContainer>
    </div>
  );
}
