// src/pages/Painel/hooks/useDashboardData.ts
import { useEffect, useState } from "react";
import axios from "axios";
import { PainelAvisosDTO } from "@/types/PainelAvisosDTO";
import { useAuth } from "@/context/AuthContext";

export default function useDashboardData() {
  const { token, usuario } = useAuth();
  const API_URL = import.meta.env.VITE_API_URL;
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState<string | null>(null);
  const [avisos, setAvisos] = useState<PainelAvisosDTO>({
    ctrcsParadosGRU: [],
    ctrcsParadosUND: [],
    ctrcsAtrasadas: [],
    ctrcsVaiAtrasar: [],
  });


   useEffect(() => {
    async function load() {
      try {
        setLoading(true);

        const res = await axios.get(`${API_URL}/api/painel/avisos`, {
          headers: { Authorization: `Bearer ${token}` }
        });

        setAvisos(res.data);

      } catch (err) {
        console.error(err);
        setErro("Erro ao carregar dados do painel.");
      } finally {
        setLoading(false);
      }
    }

    load();
  }, []);

  return {
    loading,
    erro,
    ...avisos
  };
 
}
