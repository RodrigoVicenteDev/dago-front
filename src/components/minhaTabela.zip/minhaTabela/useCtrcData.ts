import { useState, useEffect, useRef } from "react";
import axios from "axios";
import { useAuth } from "@/context/AuthContext";

export function useCtrcData() {
  const { token } = useAuth();
  const API_URL = import.meta.env.VITE_API_URL;

  // ESTADOS PRINCIPAIS
  const [rows, setRows] = useState<any[]>([]);
  const [allRows, setAllRows] = useState<any[]>([]);
  const [dirty, setDirty] = useState<Record<number, any>>({});  // ✅ ADICIONADO
  const [loading, setLoading] = useState(false);

  const [unidades, setUnidades] = useState<string[]>([]);
  const [statuses, setStatuses] = useState<any[]>([]);
  const [statusesById, setStatusesById] = useState<Record<number, string>>({});

  const [periodo, setPeriodo] = useState({
    dataInicio: "",
    dataFim: "",
  });

  const [isEsporadico, setIsEsporadico] = useState(false);

  const gridRef = useRef<any>(null);

  // AGENDA MODAL
  const [agendaModalVisible, setAgendaModalVisible] = useState(false);
  const [agendaCTRCId, setAgendaCTRCId] = useState<number | null>(null);
  const [agendaDataAtual, setAgendaDataAtual] = useState<string | null>(null);

  function handleAbrirAgendaModal(id: number, data: string | null) {
    setAgendaCTRCId(id);
    setAgendaDataAtual(data);
    setAgendaModalVisible(true);
  }

  async function handleSalvarAgenda(novaData: string | null) {
    if (!agendaCTRCId) return;
    try {
      await axios.put(
        `${API_URL}/api/ctrcs/${agendaCTRCId}/agenda`,
        { novaData },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setAllRows((prev) =>
        prev.map((r) =>
          r.id === agendaCTRCId ? { ...r, dataAgenda: novaData } : r
        )
      );

      setRows((prev) =>
        prev.map((r) =>
          r.id === agendaCTRCId ? { ...r, dataAgenda: novaData } : r
        )
      );
    } catch (err) {
      console.error("Erro ao salvar agenda:", err);
    }

    setAgendaModalVisible(false);
  }

  // --- CARREGAR GRID ---
  async function fetchGrid() {
    setLoading(true);
    try {
      const res = await axios.get(`${API_URL}/api/ctrcs/grid`, {
        params: periodo,
        headers: { Authorization: `Bearer ${token}` },
      });

      const data = res.data ?? [];

      setAllRows(data);
      setRows(data);

      // UND
      const unds = Array.from(new Set(data.map((r: any) => r.unidade))).sort();
      setUnidades(unds);

      // STATUS LOOKUP
      const lookupRes = await axios.get(`${API_URL}/api/ctrcs/lookups`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const apiStatuses = lookupRes.data?.statusesEntrega ?? [];
      setStatuses(apiStatuses);

      setStatusesById(
        apiStatuses.reduce(
          (acc: any, s: any) => ({ ...acc, [s.id]: s.nome }),
          {}
        )
      );

      setIsEsporadico(data.some((r: any) => r?.esporadico === true));

      // auto-size
      setTimeout(() => autoSizeAllColumns(), 300);
    } catch (err) {
      console.error("Erro ao carregar grid:", err);
    } finally {
      setLoading(false);
    }
  }

  function autoSizeAllColumns() {
    if (!gridRef.current) return;
    const columnApi = gridRef.current.columnApi;
    if (!columnApi) return;

    const allColumnIds: string[] = [];
    columnApi.getAllColumns().forEach((col: any) => {
      allColumnIds.push(col.getId());
    });

    columnApi.autoSizeColumns(allColumnIds, false);
  }

  // CARREGAR AO MONTAR
  useEffect(() => {
    const hoje = new Date();
    const fim = hoje.toISOString().split("T")[0];
    const inicio = new Date();
    inicio.setDate(inicio.getDate() - 30);
    const inicioStr = inicio.toISOString().split("T")[0];

    setPeriodo({ dataInicio: inicioStr, dataFim: fim });
  }, []);

  useEffect(() => {
    if (periodo.dataInicio && periodo.dataFim) {
      fetchGrid();
    }
  }, [periodo]);

  // --- RETORNO DO HOOK ---
  return {
    rows,
    allRows,
    dirty,         // 🔥 AGORA EXISTE

    setRows,
    setAllRows,
    setDirty,      // 🔥 AGORA EXISTE

    unidades,
    statuses,
    statusesById,
    periodo,
    setPeriodo,
    fetchGrid,
    loading,
    gridRef,
    isEsporadico,

    agendaModalVisible,
    setAgendaModalVisible,
    agendaCTRCId,
    agendaDataAtual,
    handleAbrirAgendaModal,
    handleSalvarAgenda,
  };
}
