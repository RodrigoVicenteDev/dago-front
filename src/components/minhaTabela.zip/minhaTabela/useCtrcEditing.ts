// src/components/minhaTabela/useCtrcEditing.ts
import { useCallback } from "react";

export function useCtrcEditing(ctrc: any) {
  /**
   * Função chamada quando o usuário edita uma célula do AG-Grid.
   * Ela atualiza:
   *  - rows (grid filtrado)
   *  - allRows (grid completo)
   *  - dirty (para o autosave)
   */
  const onCellEdit = useCallback(
    (params: any) => {
      const id = params.data.id;
      const field = params.colDef.field;
      let value = params.newValue;

      // 🔹 Se for status → garantir número
      if (field === "statusEntregaId") {
        value = Number(value);
      }

      // 🔹 Se for data → converter para ISO
      if (field === "dataEntregaRealizada" && value) {
        // Formato dd/MM/yyyy
        if (/^\d{2}\/\d{2}\/\d{4}$/.test(value)) {
          const [d, m, y] = value.split("/").map(Number);
          value = new Date(y, m - 1, d).toISOString();
        } else {
          // Tenta converter qualquer outro formato válido
          const dt = new Date(value);
          if (!isNaN(dt.getTime())) {
            value = dt.toISOString();
          } else {
            value = null;
          }
        }
      }

      // --------------------------------------------------------------
      // Atualiza linha editada nas linhas filtradas (rows)
      // --------------------------------------------------------------
      ctrc.setRows((prev: any[]) =>
        prev.map((r) => (r.id === id ? { ...r, [field]: value } : r))
      );

      // --------------------------------------------------------------
      // Atualiza linha editada no dataset completo (allRows)
      // --------------------------------------------------------------
      ctrc.setAllRows((prev: any[]) =>
        prev.map((r) => (r.id === id ? { ...r, [field]: value } : r))
      );

      // --------------------------------------------------------------
      // Mapeia nomes de campos frontend → backend
      // --------------------------------------------------------------
      const backendMap: Record<string, string> = {
        dataEntregaRealizada: "DataEntregaRealizada",
        statusEntregaId: "StatusEntregaId",
        observacao: "Observacao",
        descricaoOcorrenciaAtendimento: "DescricaoOcorrenciaAtendimento",
        ultimaDescricaoOcorrenciaAtendimento:
          "DescricaoOcorrenciaAtendimento",
      };

      const backendField = backendMap[field] || field;

      // --------------------------------------------------------------
      // Marca a linha como "dirty" para o autosave
      // --------------------------------------------------------------
      ctrc.setDirty((prev: any) => ({
        ...prev,
        [id]: {
          ...(prev[id] || {}),
          [backendField]: value,
        },
      }));
    },
    [ctrc]
  );

  return { onCellEdit };
}

export default useCtrcEditing;
